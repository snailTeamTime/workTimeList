var cc=[
    {
        "source": "一年级",
        "target": "超重",
        "value": "39"
    },
    {
        "source": "一年级",
        "target": "肥胖",
        "value": "38"
    },
    {
        "source": "一年级",
        "target": "正常体重",
        "value": "191"
    },
    {
        "source": "一年级",
        "target": "营养不良",
        "value": "18"
    },
    {
        "source": "正常体重",
        "target": "不及格",
        "value": "4"
    },
    {
        "source": "正常体重",
        "target": "及格",
        "value": "220"
    },
    {
        "source": "正常体重",
        "target": "良好",
        "value": "527"
    },
    {
        "source": "正常体重",
        "target": "优秀",
        "value": "134"
    },
    {
        "source": "营养不良",
        "target": "不及格",
        "value": "2"
    },
    {
        "source": "营养不良",
        "target": "及格",
        "value": "42"
    },
    {
        "source": "营养不良",
        "target": "良好",
        "value": "48"
    },
    {
        "source": "营养不良",
        "target": "优秀",
        "value": "4"
    },
    {
        "source": "肥胖",
        "target": "不及格",
        "value": "22"
    },
    {
        "source": "肥胖",
        "target": "及格",
        "value": "196"
    },
    {
        "source": "肥胖",
        "target": "良好",
        "value": "45"
    },
    {
        "source": "超重",
        "target": "不及格",
        "value": "3"
    },
    {
        "source": "超重",
        "target": "及格",
        "value": "108"
    },
    {
        "source": "超重",
        "target": "良好",
        "value": "100"
    },
    {
        "source": "超重",
        "target": "优秀",
        "value": "7"
    },
    {
        "source": "二年级",
        "target": "超重",
        "value": "30"
    },
    {
        "source": "二年级",
        "target": "肥胖",
        "value": "42"
    },
    {
        "source": "二年级",
        "target": "正常体重",
        "value": "140"
    },
    {
        "source": "二年级",
        "target": "营养不良",
        "value": "18"
    },
    {
        "source": "三年级",
        "target": "超重",
        "value": "41"
    },
    {
        "source": "三年级",
        "target": "肥胖",
        "value": "42"
    },
    {
        "source": "三年级",
        "target": "正常体重",
        "value": "133"
    },
    {
        "source": "三年级",
        "target": "营养不良",
        "value": "12"
    },
    {
        "source": "四年级",
        "target": "超重",
        "value": "33"
    },
    {
        "source": "四年级",
        "target": "肥胖",
        "value": "55"
    },
    {
        "source": "四年级",
        "target": "正常体重",
        "value": "152"
    },
    {
        "source": "四年级",
        "target": "营养不良",
        "value": "24"
    },
    {
        "source": "五年级",
        "target": "超重",
        "value": "43"
    },
    {
        "source": "五年级",
        "target": "肥胖",
        "value": "40"
    },
    {
        "source": "五年级",
        "target": "正常体重",
        "value": "147"
    },
    {
        "source": "五年级",
        "target": "营养不良",
        "value": "15"
    },
    {
        "source": "六年级",
        "target": "超重",
        "value": "32"
    },
    {
        "source": "六年级",
        "target": "肥胖",
        "value": "46"
    },
    {
        "source": "六年级",
        "target": "正常体重",
        "value": "122"
    },
    {
        "source": "六年级",
        "target": "营养不良",
        "value": "9"
    }
];

var  data=[{
    "name": "一年级"
}, {
    "name": "二年级"
}, {
    "name": "三年级"
}, {
    "name": "四年级"
}, {
    "name": "五年级"
}, {
    "name": "六年级"
}, {
    "name": "超重"
}, {
    "name": "肥胖"
}, {
    "name": "正常体重"
}, {
    "name": "营养不良"
}, {
    "name": "不及格"
}, {
    "name": "及格"
}, {
    "name": "良好"
}, {
    "name": "优秀"
}];


